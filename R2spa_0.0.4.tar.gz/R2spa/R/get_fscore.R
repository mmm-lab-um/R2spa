#' Get Factor Scores and the Corresponding Standard Error of Measurement
#'
#' @description
#' `get_fs()` is an S3 generic that extracts factor scores from fitted models.
#' Methods are available for `data.frame` (fits a CFA internally), `lavaan`
#' objects, and `lmerMod` objects. Support for `mirt` models is planned.
#'
#' @details
#' When `data` is a data frame and `model` is supplied as a lavaan syntax string,
#' the function internally calls [lavaan::cfa()] and then dispatches to the
#' `lavaan` method. When `data` is a fitted model object, the appropriate S3
#' method is called directly.
#'
#' `get_fs()` replaced `get_fs_lavaan()` and `get_fs_lmer()`, which are now
#' thin wrappers retained for backward compatibility.
#'
#' @param data A data frame, a fitted [lavaan] model object, or a fitted
#'        [lme4::lmer] model object (`merMod`).
#' @param model An optional string specifying the measurement model
#'              in \code{lavaan} syntax. Only used when `data` is a data frame.
#'              See \code{\link[lavaan]{model.syntax}} for more information.
#' @param group Character. Name of the grouping variable for multiple group
#'              analysis, which is passed to \code{\link[lavaan]{cfa}}.
#'              Only used when `data` is a data frame.
#' @param method Character. Method for computing factor scores (options are
#'               "regression" or "Bartlett"). Currently, the default is
#'               "regression" to be consistent with
#'               \code{\link[lavaan]{lavPredict}}, but the Bartlett scores have
#'               more desirable properties and may be preferred for 2S-PA.
#' @param corrected_fsT Logical. Whether to correct for the sampling
#'                      error in the factor score weights when computing
#'                      the error variance estimates of factor scores.
#' @param vfsLT Logical. Whether to return the covariance matrix of `fsT`
#'              and `fsL`, which can be used as input for [vcov_corrected()]
#'              to obtain corrected covariances and standard errors for
#'              [tspa()] results. This is currently ignored.
#' @param reliability Logical. Whether to return the reliability of factor
#'                    scores. Available only for single-factor lavaan models.
#' @param format Output format when `data` is a lavaan or merMod object.
#'        `"unified"` (default) returns a single data frame with a `group` column;
#'        for multiple groups, attributes `fsT`, `fsL`, `fsb`, and `scoring_matrix`
#'        are named lists keyed by group label. `"list"` returns the legacy
#'        shape: a named list of data frames (one per group) with per-group
#'        matrix attributes. Use [fs_to_group_list()] to convert between the two.
#' @param ... additional arguments passed to \code{\link[lavaan]{cfa}}
#'            (when `data` is a data frame). See \code{\link[lavaan]{lavOptions}}
#'            for a complete list.
#' @return A data frame containing the factor scores (with prefix `"fs_"`),
#'         the standard errors (with suffix `"_se"`), the implied loadings
#'         of indicator `_by_` factor scores, and the error variance-covariance
#'         of the factor scores (with prefix `"ev_"` or `"ecov_"`).
#'         For multi-group lavaan models in `"unified"` format, a `group` column
#'         is included. The following attributes are attached:
#'         * `fsT`: error covariance of factor scores (matrix or named list by group)
#'         * `fsL`: loading matrix of factor scores (matrix or named list by group)
#'         * `fsb`: intercepts of factor scores (vector or named list by group)
#'         * `scoring_matrix`: weights for computing factor scores from items
#' @importFrom lavaan cfa sem
#' @importFrom lavaan lavInspect lavTech coef
#' @importFrom stats setNames
#'
#' @export
#'
#' @examples
#' library(lavaan)
#' get_fs(PoliticalDemocracy[c("x1", "x2", "x3")])
#'
#' # Multiple factors
#' get_fs(PoliticalDemocracy[c("x1", "x2", "x3", "y1", "y2", "y3", "y4")],
#'        model = " ind60 =~ x1 + x2 + x3
#'                  dem60 =~ y1 + y2 + y3 + y4 ")
#'
#' # Multiple-group
#' hs_model <- ' visual  =~ x1 + x2 + x3 '
#' fit <- cfa(hs_model,
#'            data = HolzingerSwineford1939,
#'            group = "school")
#' get_fs(HolzingerSwineford1939, hs_model, group = "school")
#' # Or without the model
#' get_fs(HolzingerSwineford1939[c("school", "x4", "x5", "x6")],
#'        group = "school")

get_fs <- function(data, ...) {
  UseMethod("get_fs")
}

#' @rdname get_fs
#' @export
get_fs.data.frame <- function(data, model = NULL, group = NULL,
                              method = c("regression", "Bartlett"),
                              corrected_fsT = FALSE,
                              vfsLT = FALSE,
                               reliability = FALSE,
                               format = c("unified", "list"),
                               ...) {
  if (!is.data.frame(data)) data <- as.data.frame(data)
  if (is.null(model)) {
    ind_names <- colnames(data)
    if (!is.null(group)) {
      ind_names <- setdiff(ind_names, group)
    }
    model <- paste("f1 =~",
                    paste(ind_names, collapse = " + "))
  }
  fit <- cfa(model, data = data, group = group, ...)
  get_fs(fit, method = method,
          corrected_fsT = corrected_fsT,
          vfsLT = vfsLT,
          reliability = reliability,
          format = format)
}

get_fs_blocks.lavaan <- function(object, method, add_to_evfs, ...) {
  method <- match.arg(method, c("regression", "Bartlett"))
  est <- lavInspect(object, what = "est")
  y <- lavInspect(object, what = "data")
  miss_pat <- object@Data@Mp

  prepare_fs <- function(y, est, add, mp, method) {
    if (is.null(mp)) {
      fscore <-
        compute_fscore(y,
                       lambda = est$lambda,
                       theta = est$theta,
                       psi = est$psi,
                       nu = est$nu,
                       alpha = est$alpha,
                       method = method,
                       fs_matrices = TRUE
        )
      list(
        case_idx = seq_len(nrow(y)),
        fs = fscore,
        fsT = attr(fscore, "fsT") + add,
        fsL = attr(fscore, "fsL"),
        fsb = attr(fscore, "fsb"),
        scoring_matrix = attr(fscore, "scoring_matrix")
      )
    } else {
      npat <- mp$npatterns
      pats <- mp$pat
      mis_idx <- mp$case.idx
      blocks <- vector("list", npat)
      for (m in seq_len(npat)) {
        idx_m <- mis_idx[[m]]
        pat_m <- pats[m, ]
        fs_m <-
          compute_fscore(y[idx_m, pat_m, drop = FALSE],
                         lambda = est$lambda[pat_m, , drop = FALSE],
                         theta = est$theta[pat_m, pat_m, drop = FALSE],
                         psi = est$psi,
                         nu = est$nu[pat_m, , drop = FALSE],
                         alpha = est$alpha,
                         method = method,
                         fs_matrices = TRUE
          )
        blocks[[m]] <- list(
          case_idx = idx_m,
          fs = fs_m,
          fsT = attr(fs_m, "fsT") + add,
          fsL = attr(fs_m, "fsL"),
          fsb = attr(fs_m, "fsb"),
          scoring_matrix = attr(fs_m, "scoring_matrix")
        )
      }
      blocks
    }
  }

  # Direct slot access avoids lavInspect()'s per-call version-compatibility
  # check (lav_object_check_version(), which re-reads lavaan's DESCRIPTION
  # file via read.dcf() every time) -- a major source of overhead when
  # get_fs() is called repeatedly. @Data@ngroups is already relied upon
  # elsewhere in this file (e.g. @Data@Mp, @Data@group.label).
  ngroups <- object@Data@ngroups

  if (ngroups == 1) {
    blocks <- prepare_fs(y, est, add_to_evfs[[1]], miss_pat[[1]], method)
    if (is.null(miss_pat[[1]])) {
      blocks <- list(blocks)
    }
    return(setNames(list(blocks), ""))
  }

  group_labels <- object@Data@group.label
  blocks_by_group <- setNames(vector("list", ngroups), group_labels)

  for (g in seq_len(ngroups)) {
    grp_est <- est[[g]]
    grp_y <- y[[g]]
    grp_add <- add_to_evfs[[g]]
    grp_mp <- miss_pat[[g]]
    blocks_by_group[[g]] <- prepare_fs(grp_y, grp_est, grp_add, grp_mp, method)
    if (is.null(grp_mp)) {
      blocks_by_group[[g]] <- list(blocks_by_group[[g]])
    }
  }

  blocks_by_group
}

#' @rdname get_fs
#' @param object A fitted model object. For [get_fs()], the first argument is
#'        named `data` (dispatch argument). Methods accept `object` as their
#'        first parameter name internally.
#' @param format Output format: `"unified"` returns a single data frame with
#'        a `group` column; `"list"` returns a list of data frames per group.
#' @export
get_fs.default <- function(data, ...) {
  if (is.matrix(data)) {
    data <- as.data.frame(data)
    return(get_fs(data, ...))
  }
  stop("get_fs() is not implemented for objects of class '",
        paste(class(data), collapse = "', '"),
        "'. Currently supported: 'data.frame', 'lavaan', ",
        "and 'lmerMod'. Support for 'mirt' models is planned.",
        call. = FALSE)
}

#' @rdname get_fs
#' @param object A fitted model object.
#' @param format Output format: `"unified"` returns a single data frame with
#'        a `group` column; `"list"` returns a list of data frames per group.
#' @export
get_fs.lavaan <- function(object,
                          method = c("regression", "Bartlett"),
                          corrected_fsT = FALSE,
                          vfsLT = FALSE,
                          reliability = FALSE,
                          format = c("unified", "list"),
                          ...) {
  if (!inherits(object, "lavaan")) {
    stop("`object` must be a `lavaan` model object.")
  }
  format <- match.arg(format)

  if (reliability) corrected_fsT <- TRUE
  if (corrected_fsT) {
    add_to_evfs <- correct_evfs(object, method = method)
  } else {
    # Direct slot access; see note in get_fs_blocks.lavaan() -- avoids
    # lavInspect()'s expensive per-call version check.
    add_to_evfs <- rep(0, object@Data@ngroups)
  }

  blocks_by_group <- get_fs_blocks.lavaan(object, method = method,
                                          add_to_evfs = add_to_evfs)

  group_var <- object@Data@group
  group_col <- if (length(group_var) > 0) group_var else NULL

  out <- assemble_fs_blocks(blocks_by_group, format = format,
                            group_col = group_col)

  if (vfsLT) {
    attr(out, "vfsLT") <- vcov_ld_evfs(object, method = method)
  }
  if (reliability) {
    est <- lavInspect(object, what = "est")
    group_labels <- object@Data@group.label
    ngroups <- object@Data@ngroups
    multifactor <- if (ngroups > 1) {
      length(attr(out, "fsb")[[1]]) > 1
    } else {
      length(attr(out, "fsb")) > 1
    }
    if (multifactor) {
      warning("Computation of reliability for a multi-factor model is not ",
              "currently supported. ")
    } else {
      if (ngroups == 1) {
        is_std.lv <- all(est$psi == 1)
        attr(out, "reliability") <-
          compute_fsrel(object, method = method)[[1]]
      } else {
        is_std.lv <- all(unlist(lapply(est, function(x) x$psi)) == 1)
        rels <- compute_fsrel(object, method = method)
        group_n <- lavInspect(object, what = "norig")
        rels[ngroups + 1] <- sum(unlist(rels) * group_n / sum(group_n))
        attr(out, "reliability") <-
          setNames(rels, c(group_labels, "overall"))
      }
      if (!is_std.lv) {
        warning(
          "Computation of reliability may not be accurate when ",
          "the latent variables are not standardized. "
        )
      }
    }
  }
  out
}

#' @inherit get_fs
#' @param lavobj A lavaan model object when using [get_fs_lavaan()].
#'
#' @details
#' `get_fs_lavaan()` is superseded by [get_fs()]. It is retained for backward
#' compatibility and delegates to `get_fs(object, format = "list")` internally.
#' New code should call [get_fs()] directly.
#'
#' @export
get_fs_lavaan <- function(lavobj,
                          method = c("regression", "Bartlett"),
                          corrected_fsT = FALSE,
                          vfsLT = FALSE,
                          reliability = FALSE,
                          ...) {
  get_fs(lavobj, method = method,
         corrected_fsT = corrected_fsT,
         vfsLT = vfsLT,
         reliability = reliability,
         format = "list",
         ...)
}

#' Convert Unified Factor Scores to Group List (or Vice Versa)
#'
#' @description
#' `fs_to_group_list()` converts a unified factor-score data frame
#' (single data frame with a `group` column and list-valued attributes)
#' into the legacy list-of-data-frames shape with per-group attributes.
#' It acts as its own inverse: if given a group list, it converts back to
#' the unified shape.
#'
#' @param fs Object returned by [get_fs()]. Either a unified data frame
#'           (with a `group` column and list-valued attributes) or a named
#'           list of data frames (one per group) with per-group attributes.
#'
#' @return If `fs` is a unified data frame, returns a named list of data
#'         frames, one per group, with `fsT`, `fsL`, `fsb`, and
#'         `scoring_matrix` attached as per-group attributes on each element
#'         and as list-valued attributes on the outer list. If `fs` is a
#'         group list, returns a single data frame with a `group` column and
#'         list-valued attributes. A single-group input returns a single
#'         data frame (not a list) in either direction.
#'
#' @export
#'
#' @examples
#' library(lavaan)
#' hs_model <- "visual =~ x1 + x2 + x3"
#' fit <- cfa(hs_model, data = HolzingerSwineford1939, group = "school")
#' fs_unified <- get_fs(fit)                     # unified df
#' fs_list <- fs_to_group_list(fs_unified)       # list-of-df shape
#' fs_back <- fs_to_group_list(fs_list)          # back to unified
#' all.equal(fs_unified, fs_back, check.attributes = FALSE)
fs_to_group_list <- function(fs) {
  attr_keys <- c("fsT", "fsL", "fsb", "scoring_matrix")

  if (is.data.frame(fs)) {
    if (!"group" %in% names(fs)) {
      stop("Input data frame does not have a 'group' column. ",
           "It may already be in list format or a single-group result.",
           call. = FALSE)
    }

    group_labels <- unique(fs$group)

    if (length(group_labels) == 1) {
      out <- fs[, !names(fs) %in% "group", drop = FALSE]
      for (ak in attr_keys) {
        outer <- attr(fs, ak)
        if (is.list(outer) && length(outer) == 1L) {
          attr(out, ak) <- outer[[1L]]
        } else {
          attr(out, ak) <- outer
        }
      }
      return(out)
    }

    grp_dfs <- split(fs, fs$group)
    grp_dfs <- grp_dfs[group_labels]
    for (g in group_labels) {
      grp_dfs[[g]] <- grp_dfs[[g]][, !names(grp_dfs[[g]]) %in% "group",
                                   drop = FALSE]
      for (ak in attr_keys) {
        outer <- attr(fs, ak)
        if (is.list(outer) && !is.null(names(outer))) {
          attr(grp_dfs[[g]], ak) <- outer[[g]]
        } else {
          attr(grp_dfs[[g]], ak) <- outer
        }
      }
    }

    # Re-attach outer list-level attributes
    for (ak in attr_keys) {
      outer <- attr(fs, ak)
      if (is.list(outer)) {
        attr(grp_dfs, ak) <- outer
      }
    }
    grp_dfs

  } else if (is.list(fs)) {
    group_labels <- names(fs)
    if (is.null(group_labels) || !all(nzchar(group_labels))) {
      stop("Group list must be named (by group label).", call. = FALSE)
    }

    if (length(group_labels) == 1) {
      out <- fs[[1L]]
      if ("group" %in% names(out)) {
        out <- out[, !names(out) %in% "group", drop = FALSE]
      }
      return(out)
    }

    group_dfs <- lapply(group_labels, function(g) {
      df <- fs[[g]]
      if ("group" %in% names(df)) {
        df <- df[, !names(df) %in% "group", drop = FALSE]
      }
      df$group <- g
      df
    })
    unified <- do.call(rbind, group_dfs)

    for (ak in attr_keys) {
      per_grp <- lapply(group_labels, function(g) {
        a <- attr(fs[[g]], ak)
        if (!is.null(a)) return(a)
        outer <- attr(fs, ak)
        if (is.list(outer) && !is.null(names(outer))) return(outer[[g]])
        NULL
      })
      if (!all(vapply(per_grp, is.null, logical(1)))) {
        attr(unified, ak) <- setNames(per_grp, group_labels)
      }
    }
    unified

  } else {
    stop("'fs' must be data frame or list.", call. = FALSE)
  }
}

augment_fs <- function(fs, fs_ev) {
  fs_se <- t(as.matrix(sqrt(diag(fs_ev))))
  # fs_se[is.nan(fs_se)] <- 0
  colnames(fs) <- paste0("fs_", colnames(fs))
  colnames(fs_se) <- paste0(colnames(fs_se), "_se")
  num_lvs <- ncol(fs_ev)
  fs_evs <- rep(NA, num_lvs * (num_lvs + 1) / 2)
  count <- 1
  for (i in seq_len(num_lvs)) {
    for (j in seq_len(i)) {
      fs_evs[count] <- fs_ev[i, j]
      if (i == j) {
        names(fs_evs)[count] <- paste0("ev_", rownames(fs_ev)[i])
      } else {
        names(fs_evs)[count] <- paste0("ecov_",
                                       rownames(fs_ev)[i], "_",
                                       colnames(fs_ev)[j])
      }
      count <- count + 1
    }
  }
  fsL <- attr(fs, "fsL")
  fs_names <- paste0("fs_", colnames(fsL))
  fs_lds <- lapply(seq_len(ncol(fsL)), function(i) {
    setNames(fsL[, i],
             paste(colnames(fsL)[i], fs_names, sep = "_by_"))
  })
  fs_lds <- unlist(fs_lds)
  fs_dat <- cbind(as.data.frame(fs), fs_se, t(as.matrix(fs_lds)),
                  t(as.matrix(fs_evs)))
  attr(fs_dat, "fsT") <- fs_ev
  attr(fs_dat, "fsL") <- fsL
  attr(fs_dat, "fsb") <- attr(fs, "fsb")
  attr(fs_dat, "scoring_matrix") <- attr(fs, "scoring_matrix")
  fs_dat
}

check_blocks_identical <- function(a, b, keys) {
  all(vapply(keys, function(k) {
    identical(a[[k]], b[[k]])
  }, logical(1)))
}

assemble_fs_blocks <- function(blocks_by_group,
                               format = c("unified", "list"),
                               group_col = NULL) {
  format <- match.arg(format)
  group_labels <- names(blocks_by_group)
  if (is.null(group_labels) || !all(nzchar(group_labels))) {
    group_labels <- rep("", length(blocks_by_group))
  }
  attr_keys <- c("fsT", "fsL", "fsb", "scoring_matrix")

  group_dfs <- vector("list", length(group_labels))
  names(group_dfs) <- group_labels

  for (g in seq_along(group_labels)) {
    grp <- group_labels[g]
    blocks <- blocks_by_group[[g]]
    n_cases <- max(unlist(lapply(blocks, function(b) max(b$case_idx))))

    aug_list <- lapply(blocks, function(b) {
      augment_fs(b$fs, b$fsT)
    })

    template_cols <- names(aug_list[[1]])
    grp_df <- as.data.frame(
      matrix(NA, nrow = n_cases, ncol = length(template_cols))
    )
    colnames(grp_df) <- template_cols

    for (bl in seq_along(blocks)) {
      grp_df[blocks[[bl]]$case_idx, ] <- aug_list[[bl]]
    }

    block_attrs <- lapply(blocks, function(b) {
      list(
        fsT = b$fsT,
        fsL = if (!is.null(b$fsL)) b$fsL else attr(b$fs, "fsL"),
        fsb = if (!is.null(b$fsb)) b$fsb else attr(b$fs, "fsb"),
        scoring_matrix = if (!is.null(b$scoring_matrix)) b$scoring_matrix
          else attr(b$fs, "scoring_matrix")
      )
    })

    if (length(blocks) > 1) {
      all_same <- vapply(seq_len(length(blocks))[-1], function(i) {
        check_blocks_identical(block_attrs[[i]], block_attrs[[1]], attr_keys)
      }, logical(1))
      if (!all(all_same)) {
        message("Group '", grp, "': blocks have differing fsT/fsL/fsb attributes ",
                "(e.g. due to missing-data patterns). Using first block as ",
                "representative for group-level attributes.")
      }
    }
    repr <- block_attrs[[1]]

    for (ak in attr_keys) {
      attr(grp_df, ak) <- repr[[ak]]
    }

    group_dfs[[g]] <- grp_df
  }

  if (format == "list") {
    if (length(group_labels) == 1 && group_labels == "") {
      return(group_dfs[[1]])
    }

    if (!is.null(group_col)) {
      for (g in seq_along(group_labels)) {
        if (!group_col %in% names(group_dfs[[g]])) {
          group_dfs[[g]][[group_col]] <- group_labels[g]
        }
      }
    }

    outer_attr_names <- setdiff(
      names(attributes(group_dfs[[1]])),
      c("names", "class", "row.names", "col.names")
    )
    for (ak in outer_attr_names) {
      attr_lst <- setNames(
        lapply(group_dfs, function(df) attr(df, ak)),
        group_labels
      )
      attr(group_dfs, ak) <- attr_lst
    }
    return(group_dfs)
  }

  for (g in seq_along(group_labels)) {
    group_dfs[[g]]$group <- group_labels[g]
  }
  unified_df <- do.call(rbind, group_dfs)

  for (ak in attr_keys) {
    attr(unified_df, ak) <- setNames(
      lapply(group_dfs, function(df) attr(df, ak)),
      group_labels
    )
  }

  unified_df
}

get_fs_blocks.merMod <- function(object, ...) {
  num_re <- length(object@cnms[[1]])
  re_names <- paste0("u", seq_len(num_re) - 1, "_eb")

  u_eb <- as.data.frame(lme4::ranef(object)[[1]])
  colnames(u_eb) <- re_names

  cluster_levels <- unique(as.character(object@flist[[1]]))
  mf <- model.frame(object)
  case_idx <- split(seq_len(nrow(mf)), object@flist[[1]])

  Xlist <- split(data.frame(object@pp$X), object@flist[[1]])
  D <- get_D(object@theta)
  s <- stats::sigma(object)

  n_clus <- length(Xlist)
  blocks <- vector("list", n_clus)

  for (j in seq_len(n_clus)) {
    xj <- as.matrix(Xlist[[j]])
    Kz <- crossprod(xj)
    DKz <- D %*% Kz
    inv_W <- solve(DKz + diag(nrow(Kz)))
    fsL_j <- DKz - DKz %*% inv_W %*% DKz
    fsT_j <- s^2 * inv_W %*% DKz %*% D %*% t(inv_W)

    fs_row <- as.matrix(u_eb[j, , drop = FALSE])
    colnames(fs_row) <- re_names

    # colnames = lv names, rownames = fs names (for augment_fs consistency)
    colnames(fsL_j) <- re_names
    rownames(fsL_j) <- paste0("fs_", re_names)
    attr(fs_row, "fsL") <- fsL_j

    rownames(fsT_j) <- colnames(fsT_j) <- paste0("fs_", re_names)
    rownames(fsT_j) <- colnames(fsT_j) <- re_names

    blocks[[j]] <- list(
      case_idx = case_idx[[j]],
      fs = fs_row,
      fsL = fsL_j,
      fsT = fsT_j,
      fsb = NULL,
      scoring_matrix = NULL
    )
  }

  setNames(blocks, cluster_levels)
}
get_D <- function(theta) {
    L_D <- lme4::vec2mlist(theta, symm = FALSE)[[1]]
    tcrossprod(L_D)
}

#' @rdname get_fs
#' @param object A fitted model object.
#' @param format Output format: `"unified"` returns a single data frame with
#'        a `group` column; `"list"` returns a list of data frames per group.
#'        For `merMod` objects there is always a single implicit group, so
#'        `"list"` returns a bare data frame.
#' @export
get_fs.merMod <- function(object,
                          method = c("EB"),
                          corrected_fsT = FALSE,
                          vfsLT = FALSE,
                          fsm = FALSE,
                          format = c("unified", "list"),
                          ...) {
  if (!inherits(object, "merMod")) {
    stop("`object` must be an `lmerMod` model object.", call. = FALSE)
  }

  blocks <- get_fs_blocks.merMod(object)

  # NOTE: merMod does NOT route through assemble_fs_blocks(). The shared
  # assembler assumes one data row per individual case (nrow = n_cases),
  # filling a template DataFrame by case_idx. merMod's semantics produce
  # one row per cluster (nrow = n_clusters), because each cluster has a
  # single EB estimate shared across its cases. Forcing it through the
  # assembler would produce n_cases rows with repeated values, breaking
  # backward compatibility with ranef()-aligned output. This is an
  # intentional architectural exception.
  aug_list <- lapply(blocks, function(b) {
    augment_fs(b$fs, b$fsT)
  })
  out <- do.call(rbind, aug_list)

  # Per-cluster fsL/fsT as array attributes (merMod-specific: each cluster
  # has its own covariance matrix, unlike lavaan groups where attributes are
  # shared within a group).
  n_clus <- length(blocks)
  num_re <- ncol(blocks[[1]]$fsT)
  re_names <- paste0("u", seq_len(num_re) - 1, "_eb")
  fs_names <- paste0("fs_", re_names)
  fsL_arr <- array(0, dim = c(num_re, num_re, n_clus),
                    dimnames = list(fs_names, re_names, names(blocks)))
  fsT_arr <- array(0, dim = c(num_re, num_re, n_clus),
                    dimnames = list(fs_names, fs_names, names(blocks)))
  for (j in seq_len(n_clus)) {
    fsL_arr[, , j] <- blocks[[j]]$fsL
    fsT_arr[, , j] <- blocks[[j]]$fsT
  }
  attr(out, "fsL") <- fsL_arr
  attr(out, "fsT") <- fsT_arr

  if (format[1] == "unified") {
    out$group <- ""
  }
  out
}

#' Get Factor Scores and the Corresponding Scoring Matrices for
#' Mixed-Effect Models
#'
#' @description
#' `get_fs_lmer()` is superseded by [get_fs()]. It is retained for backward
#' compatibility and delegates to `get_fs(object)` internally. New code should
#' call [get_fs()] directly.
#'
#' @param object A fitted model object of class [lme4::lmerMod-class].
#' @param method Currently only `"EB"` for empirical Bayes.
#' @param corrected_fsT Currently not used.
#' @param vfsLT Currently not used.
#' @param fsm Currently not used.
#'
#' @export
get_fs_lmer <- function(object,
                        method = c("EB"),
                        corrected_fsT = FALSE,
                        vfsLT = FALSE,
                        fsm = FALSE,
                        ...) {
  get_fs(object, format = "list", ...)
}

sqrt_or_na <- function(x) {
  sqrt(ifelse(x >= 0, x, NA))
}

augment_fs2 <- function(fs, fsL, fsT, fsb = NULL) {
  fs_se <- sqrt_or_na(diag(fsT))
  fs_lds <- c(fsL)
  fs_evs <- fsT[upper.tri(fsT, diag = TRUE)]
  fs_vec <- c(fs_se, fs_lds, fs_evs)
  if (!is.null(fsb)) {
    fs_vec <- c(fs_vec, fsb)
  }
  cbind(as.data.frame(fs), matrix(fs_vec, nrow = 1))
}

compute_lav_fs_matrices <- function(
  acov, psi = NULL, alpha = NULL,
  method = c("regression", "Bartlett")) {
  method <- match.arg(method)
  if (method == "regression") {
    fsL <- diag(nrow(acov)) - acov %*% solve(psi)
    fsT <- fsL %*% acov
    if (is.null(alpha)) {
      fsb <- NULL
    } else {
      fsb <- alpha - fsL %*% alpha
    }
  } else if (method == "Bartlett") {
    fsL <- diag(nrow(acov))
    fsT <- acov
    if (is.null(alpha)) {
      fsb <- NULL
    } else {
      fsb <- rep(0, nrow(acov))
    }
  }
  return(list(fsL = fsL, fsT = fsT, fsb = fsb))
}

create_fsT_names <- function(fs_names) {
  out <- outer(fs_names,
    Y = fs_names,
    FUN = paste, sep = "_"
  )
  out[lower.tri(out)] <- t(out)[lower.tri(out)]
  out[] <- paste0("ecov_", out)
  diag(out) <- paste0("ev_", fs_names)
  out
}

create_fsL_names <- function(lv_names, fs_names) {
  out <- outer(lv_names,
    Y = fs_names, FUN = paste,
    sep = "_by_"
  )
  t(out)
}

get_fs_mat_names <- function(lv_names, int = TRUE) {
  # Initialize data frame
  fs_names <- paste0("fs_", lv_names)
  se_names <- paste0("se_", fs_names)
  ev_names <- create_fsT_names(fs_names)
  dimnames(ev_names) <- rep(list(fs_names), 2)
  ld_names <- create_fsL_names(lv_names, fs_names = fs_names)
  dimnames(ld_names) <- list(fs_names, lv_names)
  out <- list(
    fs = fs_names, se = se_names, ld = ld_names, ev = ev_names
  )
  if (int) {
    return(c(out, int = paste0("int_", fs_names)))
  } else {
    return(out)
  }
}

#' Obtain factor scores and related definition variables from
#' a `lavaan` object for 2S-PA analyses.
#'
#' This function obtained the factor scores, standard errors,
#' loading matrix, and variance covariance matrix by calling
#' the [lavaan::lavPredict()] function.
#'
#' @param lavobj A fitted [`lavaan::lavaan-class`] object
#' @param method A character string indicating the scoring method to use.
#'               Must be either `"regression"` or `"Bartlett"`.
#' @param drop_list_single logical. Should the results be unlisted
#'                         for single-group models?
#' @param ... Additional arguments passed to [lavaan::lavPredict()]
#' @return A `data.frame` containing the factor scores, the corresponding
#'         standard errors, the loadings and cross-loadings of the factor
#'         scores as indicators of the latent variables, the 
#'         error variance-covariance matrix of the factor scores,
#'         and the measurement intercepts.
#'         In addition, three character matrices are added as attributes
#'         that can be used as input to [tspa_mx_model()]:
#' * `ld`: cross-loading matrix
#' * `ev`: error variance-covariance matrix
#' * `int`: measurement intercepts
#' @export
#' @examples
#' library(lavaan)
#' hs_model <- ' visual  =~ x1 + x2 + x3 '
#' fit <- cfa(hs_model,
#'            data = HolzingerSwineford1939,
#'            group = "school")
#' augment_lav_predict(fit)
augment_lav_predict <- function(
    lavobj, method = c("regression", "Bartlett"),
    drop_list_single = TRUE, ...) {
  method <- match.arg(method)
  mp_lst <- lavobj@Data@Mp
  fs_lst <- lavaan::lavPredict(
    lavobj,
    type = "lv", method = method,
    acov = TRUE,
    ...
  )
  if (lavInspect(lavobj, what = "ngroups") == 1) {
    fs_lst <- list(fs_lst)
    attr(fs_lst, "acov") <- attr(fs_lst[[1]], "acov")
  }
  pars <- lavInspect(lavobj, what = "est",
                     drop.list.single.group = FALSE)
  out <- vector("list", length = length(fs_lst))
  names(out) <- names(fs_lst)
  has_means <- lavInspect(lavobj, what = "meanstructure")
  for (g in seq_along(fs_lst)) {
    mp <- mp_lst[[g]]
    fs <- fs_lst[[g]]
    if (is.null(mp)) {
      case_idx <- list(seq_len(nrow(fs)))
      acov_g <- list(attr(fs_lst, "acov")[[g]])
      acov_rank <- 1
    } else {
      case_idx <- mp$case.idx
      # Somehow lavaan sort the `acov` output by the missing data pattern and
      # does not match the order of the missing pattern
      # So need to find the order first
      acov_g <- attr(fs_lst, "acov")[[g]]
      acov_rank <- rank(mp$id)
    }
    # Initialize empty data frame
    fs_matnames <- get_fs_mat_names(colnames(fs),
                                    int = has_means)
    fs_colnames <- unlist(
      within(fs_matnames, expr = {
        ld <- c(ld)
        ev <- ev[upper.tri(ev, diag = TRUE)]
      })
    )
    fs_dat <- data.frame(
      matrix(NA,
        nrow = nrow(fs),
        ncol = length(fs_colnames),
        dimnames = list(NULL, fs_colnames)
      )
    )
    psi <- pars[[g]]$psi
    alpha <- pars[[g]]$alpha
    for (i in seq_along(case_idx)) {
      mat_idx <- acov_rank[i]
      fs_matrices <- compute_lav_fs_matrices(
        acov = acov_g[[mat_idx]],
        psi = psi,
        alpha = alpha,
        method = method
      )
      fs_dat[case_idx[[i]], ] <- augment_fs2(
        fs[case_idx[[i]], , drop = FALSE],
        fsL = fs_matrices$fsL,
        fsT = fs_matrices$fsT,
        fsb = fs_matrices$fsb
      )
    }
    out[[g]] <- fs_dat
  }
  if (drop_list_single && length(out) == 1) {
    out <- out[[1]]
  }
  attr(out, "ld") <- fs_matnames$ld
  attr(out, "ev") <- fs_matnames$ev
  attr(out, "int") <- fs_matnames$int
  out
}

#' Compute factor scores
#'
#' @param y An N x p matrix where each row is a response vector. If there
#'          is only one observation, it should be a matrix of one row.
#' @param lambda A p x q matrix of factor loadings.
#' @param theta A p x p matrix of unique variance-covariances.
#' @param psi A q x q matrix of latent factor variance-covariances.
#' @param nu A vector of length p of measurement intercepts.
#' @param alpha A vector of length q of latent means.
#' @param method A character string indicating the method for computing factor
#'               scores. Currently, only "regression" is supported.
#' @param center_y Logical indicating whether \code{y} should be mean-centered.
#'                 Default to \code{TRUE}.
#' @param fs_matrices Logical indicating whether covariances of the error
#'                    portion of factor scores (\code{fsT}), factor score
#'                    loading matrix (\eqn{L}; \code{fsL}) and intercept vector
#'                    (\eqn{b}; \code{fsb}) should be returned.
#'                    The loading and intercept matrices are the implied
#'                    loadings and intercepts by the model when using the
#'                    factor scores as indicators of the latent variables.
#'                    If \code{TRUE}, these matrices will be added as
#'                    attributes.
#' @param acov Logical indicating whether the asymptotic covariance matrix
#'             of factor scores should be returned as an attribute.
#'
#' @return An N x p matrix of factor scores.
#' @export
#'
#' @examples
#' library(lavaan)
#' fit <- cfa(" ind60 =~ x1 + x2 + x3
#'              dem60 =~ y1 + y2 + y3 + y4 ",
#'            data = PoliticalDemocracy)
#' fs_lavaan <- lavPredict(fit, method = "Bartlett")
#' # Using R2spa::compute_fscore()
#' est <- lavInspect(fit, what = "est")
#' fs_hand <- compute_fscore(lavInspect(fit, what = "data"),
#'                           lambda = est$lambda,
#'                           theta = est$theta,
#'                           psi = est$psi,
#'                           method = "Bartlett")
#' fs_hand - fs_lavaan  # same scores
compute_fscore <- function(y, lambda, theta, psi = NULL,
                           nu = NULL, alpha = NULL,
                           method = c("regression", "Bartlett"),
                           center_y = TRUE,
                           acov = FALSE,
                           fs_matrices = FALSE) {
  method <- match.arg(method)
  if (is.null(nu)) nu <- colMeans(y)
  if (is.null(alpha)) alpha <- matrix(0, nrow = ncol(as.matrix(lambda)))
  y1c <- t(as.matrix(y))
  if (center_y) {
    meany <- lambda %*% alpha + nu
    y1c <- y1c - as.vector(meany)
  }
  a_mat <- compute_a_from_mat(method,
                              lambda = lambda, psi = psi, theta = theta)
  fs <- t(a_mat %*% y1c + as.vector(alpha))
  if (acov) {
    # if (is.null(psi)) {
    #   stop("input of psi (latent covariance) is needed for acov")
    # }
    if (method == "regression") {
      covy <- lambda %*% psi %*% t(lambda) + theta
      attr(fs, "acov") <-
        unclass(psi - a_mat %*% covy %*% t(a_mat))
    } else if (method == "Bartlett") {
      attr(fs, "acov") <-
        unclass(a_mat %*% theta %*% t(a_mat))
    }
  }
  if (fs_matrices) {
    attr(fs, "scoring_matrix") <- a_mat
    fsL <- unclass(a_mat %*% lambda)
    fs_names <- paste0("fs_", colnames(fsL))
    rownames(fsL) <- fs_names
    attr(fs, "fsL") <- fsL
    fsb <- as.numeric(alpha - fsL %*% alpha)
    names(fsb) <- fs_names
    attr(fs, "fsb") <- fsb
    # tv <- fsL %*% psi %*% t(fsL)
    # fsv <- a_mat %*% covy %*% t(a_mat)
    # attr(fs, "fsT") <- fsv - tv
    fsT <- a_mat %*% theta %*% t(a_mat)
    rownames(fsT) <- colnames(fsT) <- fs_names
    attr(fs, "fsT") <- fsT
  }
  fs
}

compute_fspars <- function(par, lavobj, method = c("regression", "Bartlett"),
                           what = c("a", "evfs", "ldfs")) {
  method <- match.arg(method)
  what <- match.arg(what)
  # Direct slot access; avoids lavInspect()'s per-call version check.
  ngrp <- lavobj@Data@ngroups
  frees <- lavInspect(lavobj, what = "free")
  mats <- lavInspect(lavobj, what = "est")
  if (ngrp == 1) {
    frees <- list(frees)
    mats <- list(mats)
  }
  out <- vector("list", ngrp)
  mp <- lavobj@Data@Mp
  for (g in seq_len(ngrp)) {
    free <- frees[[g]]
    mat <- mats[[g]]
    free_list <- lapply(free, FUN = \(x) x[which(x > 0)])
    for (l in seq_along(free_list)) {
      for (i in free_list[[l]]) {
        mat[[l]][which(free[[l]] == i)] <- par[i]
      }
    }
    pat <- mp[[g]]$pat
    if (is.null(pat)) {
      pat <- matrix(TRUE, nrow = 1, ncol = ncol(mat$theta))
    }
    num_mp <- nrow(pat)
    out[[g]] <- vector("list", num_mp)
    for (m in seq_len(num_mp)) {
      idx <- which(pat[m, ])
      a <- do.call(compute_a_from_mat,
                   args = c(method, mat[c("lambda", "psi", "theta")],
                            idx = list(idx)))
      if (what == "a") {
        out[[g]][[m]] <- a
      } else if (what == "evfs") {
        out[[g]][[m]] <- a %*% mat$theta[idx, idx, drop = FALSE] %*% t(a)
      } else if (what == "ldfs") {
        out[[g]][[m]] <- a %*% mat$lambda[idx, , drop = FALSE]
      }
      if (num_mp == 1) {
        out[[g]] <- out[[g]][[1]]
      }
    }
  }
  out
}

compute_a <- function(par, lavobj, method = c("regression", "Bartlett")) {
  compute_fspars(par, lavobj = lavobj, method = method, what = "a")
}

compute_a_from_mat <- function(method = c("regression", "Bartlett"),
                               lambda, theta, psi = NULL, idx = NULL) {
  if (!is.null(idx)) {
    lambda <- lambda[idx, , drop = FALSE]
    theta <- theta[idx, idx, drop = FALSE]
  }
  method <- match.arg(method)
  if (method == "regression") {
    if (is.null(psi)) {
      stop("input of psi (latent covariance) is needed for regression scores")
    }
    compute_a_reg(lambda, theta = theta, psi = psi)
  } else if (method == "Bartlett") {
    compute_a_bartlett(lambda, theta = theta, psi = psi)
  }
}

compute_a_reg <- function(lambda, theta, psi) {
  covy <- lambda %*% psi %*% t(lambda) + theta
  ginvcovy <- MASS::ginv(covy)
  tlam_invcov <- crossprod(lambda, ginvcovy)
  psi %*% tlam_invcov
}

compute_a_bartlett <- function(lambda, theta, psi = NULL) {
  ginvth <- MASS::ginv(theta)
  tlam_invth <- crossprod(lambda, ginvth)
  solve(tlam_invth %*% lambda, tlam_invth)
}

correct_evfs <- function(fit, method = c("regression", "Bartlett")) {
  method <- match.arg(method)
  # Direct slot access; avoids lavInspect()'s per-call version check.
  ngrp <- fit@Data@ngroups
  est_fits <- lavInspect(fit, what = "est")
  if (ngrp == 1) est_fits <- list(est_fits)
  outs <- vector("list", ngrp)
  for (g in seq_len(ngrp)) {
    est_fit <- est_fits[[g]]
    p <- nrow(est_fit$psi)
    jac_a <- vector("list", length = p)
    for (i in seq_len(p)) {
      jac_a[[i]] <- lavaan::lav_func_jacobian_complex(
        function(x, fit, method) {
          compute_a(x, lavobj = fit, method = method)[[g]][i, ]
        },
        coef(fit),
        fit = fit,
        method = method
      )
    }
    out <- matrix(nrow = p, ncol = p)
    th <- est_fit$theta
    vc_fit <- vcov(fit)
    for (j in seq_len(p)) {
      for (i in j:p) {
        out[i, j] <- sum(diag(th %*% jac_a[[i]] %*% vc_fit %*% t(jac_a[[j]])))
        if (i > j) {
          out[j, i] <- out[i, j]
        }
      }
    }
    outs[[g]] <- out
  }
  outs
}

compute_evfs <- function(par, lavobj, method = c("regression", "Bartlett")) {
  compute_fspars(par, lavobj = lavobj, method = method, what = "evfs")
}

compute_ldfs <- function(par, lavobj, method = c("regression", "Bartlett")) {
  compute_fspars(par, lavobj = lavobj, method = method, what = "ldfs")
}

compute_grad_ld_evfs <- function(fit, method = c("regression", "Bartlett")) {
  method <- match.arg(method)
  lavaan::lav_func_jacobian_complex(
    function(x, fit, method) {
      evfs <- compute_evfs(x, lavobj = fit, method = method)
      evfs_lower <- lapply(evfs, function(x) {
        x[lower.tri(x, diag = TRUE)]
      })
      c(unlist(compute_ldfs(x, lavobj = fit, method = method)),
        unlist(evfs_lower))
    },
    coef(fit),
    fit = fit,
    method = method
  )
}

vcov_ld_evfs <- function(fit, method = c("regression", "Bartlett")) {
  method <- match.arg(method)
  jac <- compute_grad_ld_evfs(fit, method = method)
  jac %*% lavaan::vcov(fit) %*% t(jac)
}

compute_fsrel <- function(fit, method = c("regression", "Bartlett")) {
  method <- match.arg(method)
  # Direct slot access; avoids lavInspect()'s per-call version check.
  ngrp <- fit@Data@ngroups
  est_fits <- lavInspect(fit, what = "est")
  sigmas <- lavInspect(fit, "implied")
  if (ngrp == 1) {
    est_fits <- list(est_fits)
    sigmas <- list(sigmas)
  }
  vc_fit <- vcov(fit)
  a <- compute_a(coef(fit), lavobj = fit, method = method)
  outs <- vector("list", ngrp)
  for (g in seq_len(ngrp)) {
    est_fit <- est_fits[[g]]
    lam <- est_fit$lambda
    psi <- est_fit$psi
    if (ncol(lam) > 1) {
      stop("reliability is only supported for unidimensional models.")
    }
    jac_a <- lavaan::lav_func_jacobian_complex(
      function(x, fit, method) {
        compute_a(x, lavobj = fit, method = method)[[g]]
      },
      coef(fit),
      fit = fit,
      method = method
    )
    va <- jac_a %*% vc_fit %*% t(jac_a)
    aa <- crossprod(a[[g]]) + va
    outs[[g]] <- sum(diag(lam %*% psi %*% t(lam) %*% aa)) /
      sum(diag(sigmas[[g]]$cov %*% aa))
  }
  outs
}
